@echo off
chcp 65001 >nul
title Synaphe Kurulum
echo.
echo   Synaphe Windows Uygulamasi Kuruluyor...
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Synaphe"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

copy /Y "%~dp0Synaphe.ico" "%INSTALL_DIR%\Synaphe.ico" >nul
copy /Y "%~dp0Synaphe.vbs" "%INSTALL_DIR%\Synaphe.vbs" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desk = [Environment]::GetFolderPath('Desktop'); " ^
  "$s1 = $ws.CreateShortcut((Join-Path $desk 'Synaphe.lnk')); " ^
  "$s1.TargetPath = 'wscript.exe'; " ^
  "$s1.Arguments = '\"' + $env:LOCALAPPDATA + '\Synaphe\Synaphe.vbs\"'; " ^
  "$s1.IconLocation = $env:LOCALAPPDATA + '\Synaphe\Synaphe.ico,0'; " ^
  "$s1.Description = 'Synaphe AI'; " ^
  "$s1.Save(); " ^
  "$start = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'; " ^
  "$s2 = $ws.CreateShortcut((Join-Path $start 'Synaphe.lnk')); " ^
  "$s2.TargetPath = 'wscript.exe'; " ^
  "$s2.Arguments = '\"' + $env:LOCALAPPDATA + '\Synaphe\Synaphe.vbs\"'; " ^
  "$s2.IconLocation = $env:LOCALAPPDATA + '\Synaphe\Synaphe.ico,0'; " ^
  "$s2.Description = 'Synaphe AI'; " ^
  "$s2.Save();"

echo   [OK] Synaphe Masaustu ve Baslat Menusune kelebek ikonuyla eklendi!
echo   Synaphe aciliyor...
start "" wscript.exe "%INSTALL_DIR%\Synaphe.vbs"
timeout /t 2 >nul
exit /b 0
