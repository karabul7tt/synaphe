Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
url = "https://www.synapheai.com.tr/app"

edgePaths = Array( _
  "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", _
  "C:\Program Files\Microsoft\Edge\Application\msedge.exe", _
  "C:\Program Files\Google\Chrome\Application\chrome.exe", _
  "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" _
)

launched = False
For Each p In edgePaths
  If fso.FileExists(p) Then
    WshShell.Run Chr(34) & p & Chr(34) & " --app=" & url, 1, False
    launched = True
    Exit For
  End If
Next

If Not launched Then
  WshShell.Run url, 1, False
End If
